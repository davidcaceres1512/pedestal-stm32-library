
void panic(){
}